import tkinter as tk
from tkinter import PhotoImage

class ProfesijuSpele:
    def __init__(self, root):
        self.root = root
        self.root.title("Viktorīna: Tava nākotnes profesija")
        self.root.geometry("600x600")
        self.root.configure(bg="#dbe9f4")
        self.root.resizable(False, False)

        try:
            self.image = PhotoImage(file="Profesijas.png")
        except Exception:
            self.image = None

        self.jautajumi = [
            # saglabā jautājumus
            {"jautajums": "Kāds priekšmets tev skolā patīk vislabāk?", "atbildes": ["Bioloģija", "Matemātika", "Ekonomika", "Māksla"]},
            {"jautajums": "Kas tevi visvairāk raksturo?", "atbildes": ["Palīdzēt citiem", "Risināt problēmas", "Uzņemties vadību", "Izpaust radošumu"]},
            {"jautajums": "Kur tu labprātāk strādātu?", "atbildes": ["Slimnīcā", "Tehnoloģiju uzņēmumā", "Savā uzņēmumā", "Radošā studijā"]},
            {"jautajums": "Kuru aktivitāti tu izvēlētos brīvajā laikā?", "atbildes": ["Pētīt veselības jautājumus", "Būvēt robotus", "Organizēt pasākumus", "Zīmēt vai gleznot"]},
            {"jautajums": "Kas tevi visvairāk motivē?", "atbildes": ["Glābt dzīvības", "Radīt jaunas tehnoloģijas", "Gūt panākumus", "Izpaust emocijas"]},
            {"jautajums": "Kā tu parasti risini problēmas?", "atbildes": ["Meklēju palīdzību un informāciju", "Izstrādāju tehnisku risinājumu", "Plānoju stratēģiju", "Izmantoju radošu pieeju"]},
            {"jautajums": "Kāda veida filmas tev patīk?", "atbildes": ["Medicīnas drāmas", "Zinātniskā fantastika", "Biogrāfijas par uzņēmējiem", "Mākslas filmas"]},
            {"jautajums": "Kāds ir tavs sapņu darbs?", "atbildes": ["Ārsts", "Inženieris", "Uzņēmējs", "Mākslinieks"]},
            {"jautajums": "Kas tev padodas vislabāk?", "atbildes": ["Klausīties cilvēkus", "Domāt loģiski", "Pārliecināt citus", "Radīt ko jaunu"]},
            {"jautajums": "Ko tu vēlētos izdarīt pasaules labā?", "atbildes": ["Uzlabot veselības aprūpi", "Izgudrot ko noderīgu", "Palīdzēt cilvēkiem kļūt veiksmīgākiem", "Iedvesmot ar mākslu"]},
            {"jautajums": "Kādā vidē tu jūties vislabāk?", "atbildes": ["Slimnīcā", "Laboratorijā", "Birojā", "Studijā"]},
            {"jautajums": "Kāda ir tava lielākā stiprā puse?", "atbildes": ["Empātija", "Analītiskā domāšana", "Vadītprasmes", "Radošums"]},
            {"jautajums": "Kāda profesija tevi vairāk interesē?", "atbildes": ["Mediķis", "Inženieris", "Vadītājs", "Dizaineris"]},
            {"jautajums": "Ko tu visbiežāk dari komandā?", "atbildes": ["Palīdzu un atbalstu", "Radu risinājumus", "Vadu un koordinēju", "Piedāvāju idejas"]},
            {"jautajums": "Kāda vērtība tev ir vissvarīgākā?", "atbildes": ["Palīdzība", "Inovācija", "Brīvība", "Izpausme"]}
        ]

        self.nozares = {
            "Medicīna": 0,
            "Inženierija": 0,
            "Uzņēmējdarbība": 0,
            "Māksla": 0
        }

        self.jautajumu_indekss = 0

        self.create_start_screen()

    def create_start_screen(self):
        self.clear_screen()

        if self.image:
            img_label = tk.Label(self.root, image=self.image, bg="#dbe9f4")
            img_label.pack(pady=10)

        title = tk.Label(self.root, text="Kāda ir Tava nākotnes profesija?", font=("Helvetica", 22, "bold"),
                         fg="#12355b", bg="#dbe9f4")
        title.pack(pady=20)

        start_btn = tk.Button(self.root, text="Sākt", command=self.show_question,
                              font=("Helvetica", 16, "bold"), bg="#1976D2", fg="white", width=20)
        start_btn.pack(pady=20)

    def show_question(self):
        if self.jautajumu_indekss < len(self.jautajumi):
            self.clear_screen()

            jautajums = self.jautajumi[self.jautajumu_indekss]

            # jautājuma numurs
            question_number = tk.Label(self.root, text=f"Jautājums {self.jautajumu_indekss + 1} no {len(self.jautajumi)}",
                                       font=("Helvetica", 12, "bold"), bg="#dbe9f4", fg="#12355b")
            question_number.pack(pady=(10, 0))

            # jautājums
            question_label = tk.Label(self.root, text=jautajums['jautajums'],
                                      font=("Helvetica", 16, "bold"), bg="#dbe9f4", fg="#12355b", wraplength=550)
            question_label.pack(pady=10)

            for idx, atbilde in enumerate(jautajums['atbildes']):
                answer_btn = tk.Button(self.root, text=atbilde,
                                       font=("Helvetica", 12), bg="#64B5F6", fg="white", width=40,
                                       command=lambda idx=idx: self.answer(idx))
                answer_btn.pack(pady=5)

            # attēls zem atbildēm
            if self.image:
                img_label = tk.Label(self.root, image=self.image, bg="#dbe9f4")
                img_label.pack(pady=10)
        else:
            self.show_result()

    def answer(self, idx):
        if idx == 0:
            self.nozares["Medicīna"] += 1
        elif idx == 1:
            self.nozares["Inženierija"] += 1
        elif idx == 2:
            self.nozares["Uzņēmējdarbība"] += 1
        elif idx == 3:
            self.nozares["Māksla"] += 1

        self.jautajumu_indekss += 1
        self.show_question()

    def show_result(self):
        self.clear_screen()

        best_nozare = max(self.nozares, key=self.nozares.get)

        result_label = tk.Label(self.root, text=f"Tava nākotnes profesijas joma ir: {best_nozare}",
                                font=("Helvetica", 18, "bold"), fg="#2e7d32", bg="#dbe9f4")
        result_label.pack(pady=30)

        apraksti = {
            "Medicīna": "Tava līdzjūtība un rūpes par citiem liecina, ka būtu lielisks medicīnas speciālists!",
            "Inženierija": "Tava loģiskā domāšana un precizitāte rāda, ka inženierija ir Tavs aicinājums!",
            "Uzņēmējdarbība": "Tava uzņēmība un vadītprasmes palīdzēs Tev gūt panākumus biznesā!",
            "Māksla": "Tava radošā daba un iztēle ved Tevi uz mākslas pasauli!"
        }

        desc_label = tk.Label(self.root, text=apraksti[best_nozare],
                              font=("Helvetica", 14), bg="#dbe9f4", fg="#333333", wraplength=550)
        desc_label.pack(pady=20)

        if self.image:
            img_label = tk.Label(self.root, image=self.image, bg="#dbe9f4")
            img_label.pack(pady=10)

    def clear_screen(self):
        for widget in self.root.winfo_children():
            widget.destroy()

if __name__ == "__main__":
    sakne = tk.Tk()
    aplikacija = ProfesijuSpele(sakne)
    sakne.mainloop()


